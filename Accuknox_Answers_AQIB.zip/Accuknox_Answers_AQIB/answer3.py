""" ANSWER 3: Yes, Django signal signals run in the same database transaction as the caller if the signal is connected to model save
            actions such as post_save or pre_save. The signals executes as part of atomic transaction that surrounds the view or 
            model action. """
            
# Here's an example of code:

class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width
    
    def __iter__(self):
        yield {'length': self.length}
        yield {'width': self.width}
    
    rect = Rectangle(10, 20)
    
for dimension in rect:
    print(dimension)
    

#  This example is almost similar to the second answer, here the __iter__() method uses the yield keyword to return one value at a time.
#  First it yields a dictionary containing the length:
#       {'length': <VALUE_OF_LENGTH>}.
#  Then, it yields a dictionary containing the width:
#       {'width': <VALUE_OF_WIDTH>}.

# And then, the iteration over the rectangle instance will produce the output as :

# {'length': 10}
# {'width': 20}

# This approach ensures that when you iterate over the rectangle instance, you will get the length and width in the desire format.