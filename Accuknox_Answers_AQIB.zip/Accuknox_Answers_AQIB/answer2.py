"""ANSWER 2: Yes, Django signals run in the same thread as the caller by default. That is because when a signal is sent,
the connected reciever functions executes in the same thread which sends the signal. """

# Here's an example of code

class Rectangle:
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    def __iter__(self):
        return iter((self.width, self.height))
    
    rect = Rectangle(10, 20)
    
for dimension in rect:
    print(dimension)
    

# In the above example the __iter__() method returns an iterator over a tuple containing attributes as width & height

# If you iterate over the Recatngle instance, it will yield each of the dimensions in turn first width, then height.

#Output
# 10
# 20


