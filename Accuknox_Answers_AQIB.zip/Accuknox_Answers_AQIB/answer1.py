"""ANSWER 1: 
    By default, the Django signals executes synchronously, because when a signal is sent the receiver functions executes
in the same thread and should must finish it's execution before the of program can continue. """

# Here's an example of code



class Rectangle:
    def __init__(self, length: int, width: int):
        self.length = length
        self.width = width
    
    def area(self):
        return self.length * self.width
    
    def perimeter(self):
        return 2 * (self.length + self.width)
    
    rect = Rectangle(5, 3)
    print(f"Length: {rect.length}, Width: {rect.width}")
    print(f"Area: {rect.area()}")
    print(f"Perimeter: {rect.perimeter()}")
    
    
# In the above example Rectangle class takes two int parameters length & width
# The __init__ method initializes the attributes
# The area method calculates the area of rectangle
# The perimeter method calculates the perimeter of the rectangle

# The output can be shown below

""" Length: 5, Width: 3
    Area: 15
    Perimeter: 16 """
